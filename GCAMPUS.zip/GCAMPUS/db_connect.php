<?php
  
//$connection=mysqli_connect('localhost','root','');
if(!$connection)
{
    die("could not connect to the database");
}
else {
    mysqli_select_db($connection,'notice_board');
    echo "connected successfully";
}

?>