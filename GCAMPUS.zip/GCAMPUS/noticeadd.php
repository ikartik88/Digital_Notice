<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Adding to the database</title>
</head>
<body>
    <h1>adding to the database</h1>
</body>
</html>

<?php
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'notice_board');
$sub=mysqli_escape_string($con,$_POST['subject']);
$describ=mysqli_escape_string($con,$_POST['description']);
$link=mysqli_escape_string($con,$_POST['link']);
$date=date('d-M-Y');
echo "$sub";
echo "$describ";
//---------------- adding the data to the database--------------------------//
$query="INSERT INTO notice(Subject,Link,Description,Date) VALUES('$sub','$describ','$link','$date')";
$sql=mysqli_query($con,$query);
if(!$sql)
echo "data cuould not be inserted";
else {
    echo "data is inserted";
}
?>