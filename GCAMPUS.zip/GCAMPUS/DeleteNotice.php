<?php

$con=mysqli_connect('localhost','root','','notice_board') or die("not connected");
$id=$_GET['id'];
$qry="DELETE FROM `notice` WHERE Sr_No=$id";
mysqli_query($con,$qry) or die("not executed");
header('Location:display_notice.php');

?>