<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Upload Assignment</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>
    
    <div class="container">
    <h1 class="text-center text-white bg-dark">Assignments</h1>
    <br/>
    <div class="table-responsive">
    
    <table class="table table-striped table-hover">
    <thead>
    <th>Sr_No</th>
    <th>File</th>
    </thead>
    <tbody>
    <?php
    if (isset($_POST['addassign'])) {
        $file_tmpname=$_FILES['myfile']['tmp_name'];
$file_name=$_FILES['myfile']['name'];
//echo $file_name;
$stream=$_POST['stream'];
$sem=$_POST['semester'];
    if ($sem==1) {
    $sem="firstsemassign";
}
elseif ($sem==2) {
    $sem="secondsemassign";
}
elseif ($sem==3) {
    $sem="thirdsemassign";
}
elseif ($sem==4) {
    $sem="fourthsemassign";
}
elseif ($sem==5) {
    $sem="fifthsemassign";
}
elseif ($sem==6) {
    $sem="sixthsemassign";
}

$stream=$stream."assign";
//echo $stream;
$con=mysqli_connect("localhost","root","",$stream);
$destinationfile='../upload/'.$file_name;
move_uploaded_file($file_tmpname,$destinationfile);
$qry="INSERT INTO `$sem`(`filedata`) VALUES ('$destinationfile')";
//echo $qry;
$query=mysqli_query($con,$qry) or die("not inserted");
$queryshow="SELECT *FROM $sem" or die("not worked");
$run=mysqli_query($con,$queryshow);
    //$total=mysqli_num_rows($run);
 while ($result=mysqli_fetch_assoc($run)) {
    ?>
<tr>
<td>
<?php echo $result['id']; ?></td>
<td> <?php echo $result['filedata']; ?> </td>
</tr>

    <?php
}

}
    
    
    ?>
    
    </tbody>
    </table>
    </div>
    </div>
</body>
</html>
