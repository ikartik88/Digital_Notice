
<!DOCTYPE html>
<html>

<head>
    <title>Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
   
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="SRstyle.css">
    <script>
        function validate()
         {
        var st=document.myform.stream.value;
        if (st=="select") {
        alert("Please Select Any Stream");
        window.open('SRegister.php','_self');
        return false;
        }   
else{
    return true;
}
        }


    
    </script>
</head>

<body>

    <div class="modal-dialog text-center">
        <div class="col-sm-8 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                   <a href="../HomePage"> <img src="logo1.jpg" alt=""></a>
                </div>
                <form class="col-12"  action="stsavedetail.php"  method="post" name="myform" >
                    <div class="form-group">
                        <input type="text" name="adno" class="form-control" placeholder="Enter Admission No." required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="text" name="sname" class="form-control" placeholder="Enter Username" required>
                    </div>

                    <div class="form-group">
                        <input type="password" name="spwd" class="form-control" placeholder="Enter Password" required>
                    </div>
                    <div class="form-group">
                    <label for="Course">Course</label>
                    <select name="stream" id="stream" class="form-control selectpicker">
                    <option value="select">SELECT</option>
                    <option value="bca">BCA</option>
                    <option value="mca">MCA</option>
                    <option value="mba">MBA</option>
                    </select>
                     <label for="sem">Semester</label>
                    <select name="sem" id="sem" class="form-control selectpicker">
                    <option value="select">SELECT</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    </select>
                    </div>
                    <button type="submit" name="reg" class="btn" onclick=" return validate();"><i class="fas fa-sign-in-alt" ></i>Register</button>

                </form>
                <div class="col-12 forgot">
                    <a href="SLogin.php">Login</a>
                </div>
            </div>
            <!--end of modal content-->
        </div>

    </div>







</body>

</html>
<?php
/*session_start();
if ($_SESSION['user_id']) {
 echo $_SESSION['user_id'];   
}
else {
    header("Location:admin.php");
}
?>
<?php
*/
?>