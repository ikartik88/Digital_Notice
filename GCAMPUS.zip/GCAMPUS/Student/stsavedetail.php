<?php
if (isset($_POST['reg'])) {
    # code...
    $st_admno=$_POST['adno'];
$st_name=$_POST['sname'];
$st_pwd=$_POST['spwd'];
$st_strm=$_POST['stream'];
$st_sem=$_POST['sem'];
if ($st_sem==1) {
    $st_sem="firstsem";
}
elseif ($st_sem==2) {
    $st_sem="secondsem";
    }
    elseif ($st_sem==3) {
        $st_sem="thirdsem";
    }
    elseif ($st_sem==4) {
        $st_sem="fourthsem";
    }
    elseif ($st_sem==5) {
        $st_sem="fifthsem";
    }
     elseif($st_sem==6) {
         $st_sem=="sixthsem";
     }
$con=mysqli_connect("localhost","root","",$st_strm);
    $qry1="SELECT *FROM '$st_sem' WHERE Admission_No='$st_admno'";
    $data=mysqli_query($con,$qry1);
    $total=mysqli_num_rows($data);
    //$result=mysqli_fetch_assoc($total);
    if ($total==1) {
        # code...
        ?>
        <script>
        alert("record is already exist");
        window.open('SRegister.php','_self');
        </script>
        <?php
    }
    else {

//echo $strm." ".$user_name." ".$pwd." ".$admno;
$qry="INSERT INTO $st_sem(Admission_No, Student_Name, Student_Pwd,Course,Semester) VALUES ('$st_admno','$st_name','$st_pwd','$st_strm','$st_sem')";
echo $qry;
mysqli_query($con,$qry) or die("not inserted");
echo "inserted"; 
header("Location:Slogin.php"); 
    }
}

else {
    echo "<h1>.not clicked";
}

?>