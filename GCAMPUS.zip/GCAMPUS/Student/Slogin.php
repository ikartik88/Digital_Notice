<?php session_start(); ?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="SRstyle.css">
</head>

<body>

    <div class="modal-dialog text-center">
        <div class="col-sm-8 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                   <a href="../HomePage"> <img src="logo1.jpg" alt=""></a>
                </div>
                <form class="col-12" method="post" action="Assignment.php">
                    <div class="form-group">
                        <input  type="text" class="form-control" name="admno" placeholder="Enter AdmissionNo" required>
                    </div>

                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Enter Password" name="spwd" required>
                    </div>
                    <div class="form-group">
                    <label for="Course">Course</label>
                    <select name="stream" id="stream" class="form-control selectpicker">
                    <option value="select">SELECT</option>
                    <option value="bca">BCA</option>
                    <option value="MCA">MCA</option>
                    <option value="mba">MBA</option>
                    </select>
                    <label for="Semester">Semester</label>
                    <select name="semester" id="semester" class="form-control selectpicker">
                    <option value="select">SELECT</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                     </select>
                    </div>
                    <button type="submit" name="login" class="btn"><i class="fas fa-sign-in-alt"></i> Login</button>

                </form>
                <div class="col-12 forgot">
                    <a href="SRegister.php">Register</a>
                </div>
            </div>
            <!--end of modal content-->
        </div>

    </div>
</body>

</html>

<?php

//echo "entered";
if (isset($_POST['login'])) {
    //echo "hello";
$student_id=$_POST['admno'];
$student_pwd=$_POST['spwd'];
$student_stream=$_POST['stream'];
$student_sem=$_POST['semester'];
if ($student_sem==1) {
    $student_sem="firstsem";
}
elseif ($student_sem==2) {
    $student_sem="secondsem";
}
elseif ($student_sem==3) {
    $student_sem="thirdsem";
}
elseif ($student_sem==4) {
    $student_sem="fourthsem";
}
elseif ($student_sem==5) {
    $student_sem="fifthsem";
}
elseif ($student_sem==6) {
    $student_sem="sixthsem";
}
$con=mysqli_connect("localhost","root","",$student_stream);
echo $student_id.$student_pwd;
$qry="SELECT * FROM $student_sem WHERE Admission_No='$student_id' AND Course='$student_stream' AND Student_Pwd='$student_pwd'";
echo $qry;
$run=mysqli_query($con,$qry) or die("not mached");
$total=mysqli_num_rows($run);

echo "<h1>".$total;
if ($total==1) {
    $res=mysqli_fetch_assoc($run);
   
   $sessio_id=$res['Student_Name'];
   $_SESSION["stuid"]=$sessio_id;
  //echo "Hello".$res['Student_Name'];
   //echo $_SESSION["stuid"];
   header("Location:Assignment.php");     
}
else {
    echo "<h1>not matched";
    ?>
 <script>alert("enter valid credintial");
 window.open('SLogin.php','_self');
 </script>  
 <?php
}
}

/*else {
    echo "not clicked";
}*/
?>