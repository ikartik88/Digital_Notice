<?php
$user='root';
$pass='';
$db_name='notice_board';
$host='localhost';
$con=mysqli_connect($host,$user,$pass,$db_name);
if (!$con) {
    # code...
    echo "connection failed";
}
else {
    //echo "connected";
}
?>