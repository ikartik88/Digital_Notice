<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add_Notice</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container-fluid">
        <form action="noticeadd.php" method="POST">
            <table class="table">
                <thead>
                    <tr>
                        <th> <label for="Subject">Subject</label></th>
                        <th><label for="Description">Description</label></th>
                        <th><label for="Link">Link</label></th>
                        <th><label for="Date"></label></th> <?php echo date('d-M-Y'); ?>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>
                            <input type="subject" class="form-control" id="subject" placeholder="Enter Subject" name="subject" required>
                        </td>
                        <td>
                            <textarea name="description" id="desrip" cols="50" rows="5" required></textarea>
                        </td>
                        <td>
                            <input type="Link" class="form-control" id="lnk" placeholder="Link" name="link">
                        </td>
                        
                    </tr>
                </tbody>
                <tbody>
                    <tr>
                        <td>
                            <input type="submit" value="Add Notice" class="btn btn-primary active" name="add" id="ad">
                                </td>
                        <td>
                            <button type="reset" class="btn btn-danger">
                            Reset
                            </button>
                        </td>
                        <tr>
                            <td>
                                <a href="display_notice.php">Show Notice</a>
                            </td>
                        </tr>
                    </tr>
                </tbody>


            </table>
        </form>
    </div>
</body>

</html>