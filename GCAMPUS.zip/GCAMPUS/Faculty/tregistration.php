
<!DOCTYPE html>
<html>

<head>
    <title>Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="../Rstyle.css">
</head>

<body>

    <div class="modal-dialog text-center">
        <div class="col-sm-8 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                    <img src="logo1.jpg" alt="">
                </div>
                <form class="col-12"  action="fsavedetail.php"  method="post">
                    <div class="form-group">
                        <input type="text" name="eid" class="form-control" placeholder="Enter Employeid" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="text" name="empname" class="form-control" placeholder="Enter Username" required>
                    </div>

                    <div class="form-group">
                        <input type="password" name="emppwd" class="form-control" placeholder="Enter Password" required>
                    </div>
                    <button type="submit" name="reg" class="btn"><i class="fas fa-sign-in-alt"></i>Register</button>

                </form>
                <div class="col-12 forgot">
                    <a href="tlogin.php">Login</a>
                </div>
            </div>
            <!--end of modal content-->
        </div>

    </div>







</body>

</html>

<?php
session_start();
if ($_SESSION['user_id']) {
 echo $_SESSION['user_id'];   
}
else {
    header("Location:admin.php");
}
session_destroy();
?>
