<?php
session_start();
if ($_SESSION['strmid'] && $_SESSION['semid']) {
    $id=$_GET['id'];
    echo $id;
$stream=$_SESSION['strmid'];
$sem=$_SESSION['semid'];
echo $sem;
$con=mysqli_connect("localhost","root",'',$stream) or die("not conneted");
$qry="SELECT * FROM `$sem` WHERE id=$id";
mysqli_query($con,$qry) or die("not executed");
header('Location:saveassignment.php');
}
else {
    echo "not active";
}


?>