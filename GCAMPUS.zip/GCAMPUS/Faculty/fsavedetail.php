<?php
include("../connection.php");

$emp_id=$_POST['eid'];
$emp_name=$_POST['empname'];
$emp_pwd=$_POST['emppwd'];
$qryslct="SELECT * FROM FacultyRec WHERE EmpId='$emp_id'";
echo "$qryslct.<br>";
$dat=mysqli_query($con,$qryslct);
$total=mysqli_num_rows($dat);
if ($total==1) {
    # code...
    echo "Record Is already Exist";
}
echo $total;
$qry="INSERT INTO `FacultyRec`(`EmpId`, `EmpName`, `EmpPassword`) VALUES ('$emp_id','$emp_name','$emp_pwd')";
echo $qry;
$data=mysqli_query($con,$qry);
echo "record inserted";
header("Location:tlogin.php");

?>