<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AddAssignment</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <script>
    function check(){
        
    }
    
    
    </script>
</head>
<body>
    
    <div class="container">
    <form class="form-group" action="saveassignment.php" method="post" enctype="multipart/form-data">
    <table class="table">
    <thead>
    <tr>
    <th> <label for="Sr_No.">Sr_No.</label></th>
    <th><label for="assignment">Assignment</label> </th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td><input type="file" name="myfile"/></td>
    <td>
    <label for="stream">Stream</label>
    <select name="stream" id="" class="form-control" required>
    <option value="select"></option>
    <option value="MCA">MCA</option>
    <option value="BCA">BCA</option>
    <option value="MBA">MBA</option>
    </select>
    </td>
    <td>
    <label for="semester">Semester</label>
    <select name="semester" id="" class="form-control">
    <option value="select"></option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    </select>
    </td>
    </tr>
    <tr>
    <td>
    <input type="submit" value="Add Assignment" class="btn btn-success" name="addassign">
    </td>
     </tr>
    </tbody>
    </table>
    </form>
    </div>
</body>
</html>
