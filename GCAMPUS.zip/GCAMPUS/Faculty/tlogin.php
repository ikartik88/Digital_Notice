<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="tstyle.css">
</head>

<body>

    <div class="modal-dialog text-center">
        <div class="col-sm-8 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                    <img src="logo1.jpg" alt="">
                </div>
                <form class="col-12" method="POST" actiom="FDashboard.php">
                    <div class="form-group">
                        <input  type="text" class="form-control" name="userid" placeholder="Enter UserId" required>
                    </div>

                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Enter Password" name="upwd" required>
                    </div>
                    <button type="submit"  name="submit" class="btn"><i class="fas fa-sign-in-alt" name="submit"></i> Login</button>

                </form>
                
            </div>
            <!--end of modal content-->
        </div>

    </div>
</body>

</html>

<?php

include("../connection.php");
if (isset($_POST['submit'])) {
$user_id=$_POST['userid'];
$user_pwd=$_POST['upwd'];
echo $user_id.$user_pwd;
$qry="SELECT * FROM FacultyRec WHERE EmpId='$user_id' AND EmpPassword='$user_pwd'";
echo $qry;
$run=mysqli_query($con,$qry);
$total=mysqli_num_rows($run);

echo "<h1>".$total;
if ($total==1) {
    $res=mysqli_fetch_assoc($run);
   session_start();
   $_SESSION['uid']=$res['EmpId'];
   echo $res['EmpName'];
   header("Location:FDashboard.php"); 
    
}
else {
    ?>
 <script>alert("enter valid credintial");
 window.open('tlogin.php','_self');
 </script>  
 <?php
}
}

?>