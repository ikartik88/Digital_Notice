<?php
session_start();
include("../connection.php");
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="tstyle.css">
    
</head>
<div class="modal-dialog text-center">
        <div class="col-sm-8 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                    <img src="logo1.jpg" alt="">
                </div>
                <form class="col-12" method="POST" action="admin.php">
                  <div class="form-group">
                        <input type="pasword" class="form-control" placeholder="Enter Password" required name="inppass" autofocus>
                    </div>
                    <button type="submit" class="btn" name="pass"><i class="fas fa-sign-in-alt" name="pass"></i>Login</button>

                </form>
                
            </div>
            <!--end of modal content-->
        </div>

    </div>
</body>
</html>
<?php

if(isset($_POST['pass']))
{
$pwd=$_POST['inppass'];
echo "$pwd";
$qry="SELECT * FROM Password WHERE Pas='$pwd'";
$data=mysqli_query($con,$qry);
//echo $qry;
$total=mysqli_num_rows($data);
echo $total;

if ($total==1) {
        # code...
        $res=mysqli_fetch_assoc($data);
        //echo $res['id'];
        $uid=$res['id'];
        $_SESSION['user_id']=$uid;
        //echo $_SESSION['user_id'];
       header("Location:tregistration.php");
    }
    else {
        ?>
        <script>alert("Enter Corerct Password")
        window.open('admin.php','_self');
        </script>
        <?php
    }     
}
    
?>