<!DOCTYPE html>
<html>

<head>
    <title>Registration</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="Fstyle.css">
    <script>
    function redirect(){
        window.open('../add_notice.php','_blank');
    }
    function Aredirect(){
        window.open('AddAssignment.php','_blank');
    }
    function Avredirect(){
        window.open('saveassignment.php','_blank');
    }
    </script>
</head>

<body>

    <div class="modal-dialog text-center">
        <div class="col-sm-8 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                    <img src="logo1.jpg" alt="">
                </div>
                <form class="col-12"  action=""  method="post">
                  <input type="submit" name="Notice" value="Add Notice" class="btn btn-primary" onclick="redirect()"><br><br>
                    <input type="submit" name="asgin" value="View Assignment" class="btn btn-success" onclick="Aredirect()"><br><br>
                    <input type="submit" name="asgin" value="Add Assignment" class="btn bnt-info" onclick="Avredirect()"><br><br>

                </form>
            </div>
            <!--end of modal content-->
        </div>

    </div>
</body>
</html>


<?php
session_start();
//echo "<h1>". $_SESSION['uid'];
?>