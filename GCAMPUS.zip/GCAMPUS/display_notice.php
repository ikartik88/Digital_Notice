<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Notice Display</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    
    </head>
<body>
<?php
$con=mysqli_connect('localhost','root','','notice_board');

$query1=mysqli_query($con,'SELECT *FROM notice');
if (mysqli_num_rows($query1)>0) {
    echo "<table class='table table-striped'> <thead><th>Subject</th><th>Description</th><th>Link</th></thead>";
    while ($row=mysqli_fetch_assoc($query1)) 
    {
   
    echo "<tr><td>"."{$row['Subject']}"."</td>";
   echo  "<td>{$row['Link']}"."</td>";
  echo "<td>{$row['Description']}"."</td>";
  ?>
  <td> <button class="btn-danger btn"><a href="DeleteNotice.php?id= <?php echo $row['Sr_No'];?>" class="text-white">Delete </a></button></td></tr>



  <?php
  
    }
}
?>
</body>
</html>

